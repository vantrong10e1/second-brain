from pathlib import Path
import json
import requests
import msvcrt
import re

from tqdm import tqdm
from colorama import Fore, Style, init

from query_understanding import understand_query, load_domains
from ner import extract_entities
from entity_resolution import resolve_entities, build_candidates
from domain_search import domain_search
from search import search
from rag_retrieval import retrieve
from hybrid_search import hybrid_search
from reranker import rerank
from memory import (
    load_memory,
    add_message,
    get_recent_memory
)
from evaluation import evaluate_rag


# ============================================================
# COLOR
# ============================================================

init(autoreset=True)

TITLE = Fore.GREEN


# ============================================================
# CONFIG
# ============================================================

PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_DIR / "data"

CATALOG_FILE = DATA_DIR / "data_catalog.json"

OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2"

DOMAIN_TOP_K = 5
SEARCH_TOP_K = 5
RETRIEVAL_TOP_K = 5
HYBRID_TOP_K = 5
RERANK_TOP_K = 2
FACK_TOP_K = 5

FACK_KNOWLEDGE = []


# ============================================================
# SYSTEM INITIALIZATION
# ============================================================

def initialize_system():
    """Load va khoi tao cac module cua RAG system."""

    steps = [
        ("Query Understanding", load_domains),
        ("NER", lambda: True),
        ("Entity Resolution", build_candidates),
        ("Fack", load_fack),
        ("Central Data Catalog", load_catalog),
        ("Domain Search", lambda: True),
        ("Search", lambda: True),
        ("RAG Retrieval", lambda: True),
        ("Hybrid Search", lambda: True),
        ("Reranker", lambda: True),
        ("Memory", load_memory),
        ("Evaluation", lambda: True)
    ]

    for _, function in tqdm(
        steps,
        desc="Loading system",
        unit="module",
        dynamic_ncols=True,
        bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt}"
    ):
        function()

    print("System ready.")


# ============================================================
# FACK
# ============================================================

def load_fack():
    """Load Fack knowledge from data/fack.json."""

    global FACK_KNOWLEDGE

    if FACK_KNOWLEDGE:
        return FACK_KNOWLEDGE

    fack_file = DATA_DIR / "fack.json"

    if not fack_file.exists():
        return []

    try:
        with open(
            fack_file,
            "r",
            encoding="utf-8"
        ) as file:
            data = json.load(file)

        FACK_KNOWLEDGE = data.get(
            "knowledge",
            []
        )

        return FACK_KNOWLEDGE

    except (
        json.JSONDecodeError,
        OSError
    ):
        return []


def _fack_text(item):
    """Build searchable text from a Fack item."""

    return " ".join([
        str(item.get("name", "")),
        str(item.get("definition", "")),
        str(item.get("description", "")),
        str(item.get("rule", "")),
        str(item.get("sql", ""))
    ]).lower()


def search_fack(
    query,
    domain,
    resolved_entities,
    top_k=FACK_TOP_K,
    allowed_sources=None
):
    """Find Fack knowledge using resolved entities, domain and query."""

    knowledge = load_fack()

    if not knowledge:
        return []

    query_lower = str(query).lower()

    query_terms = {
        term
        for term in re.findall(
            r"[\wÀ-ỹ+#.-]+",
            query_lower
        )
        if len(term) > 1
    }

    entity_names = set()

    for entity in resolved_entities:

        canonical_name = str(
            entity.get("canonical_name", "")
        ).strip().lower()

        entity_id = str(
            entity.get("entity_id", "")
        ).strip().lower()

        if canonical_name:
            entity_names.add(canonical_name)

        if entity_id:
            entity_names.add(entity_id)

    allowed_source_set = None

    if allowed_sources is not None:
        allowed_source_set = {
            normalize_source(source)
            for source in allowed_sources
        }

    scored = []

    for item in knowledge:

        item_domain = str(
            item.get("domain", "")
        ).strip().lower()

        if domain and item_domain != str(domain).lower():
            continue

        source = item.get("source", "")

        if (
            allowed_source_set is not None
            and normalize_source(source) not in allowed_source_set
        ):
            continue

        name = str(
            item.get("name", "")
        ).strip()

        name_lower = name.lower()
        searchable_text = _fack_text(item)

        score = 0

        if name_lower and name_lower in entity_names:
            score += 100

        if name_lower and name_lower in query_lower:
            score += 50

        score += sum(
            2
            for term in query_terms
            if term in name_lower
        )

        score += sum(
            1
            for term in query_terms
            if term in searchable_text
        )

        if score > 0:
            scored.append(
                (score, item)
            )

    scored.sort(
        key=lambda pair: pair[0],
        reverse=True
    )

    return [
        item
        for _, item in scored[:top_k]
    ]


def build_fack_context(results):
    """Convert Fack results into structured LLM context."""

    context = []

    for index, item in enumerate(
        results,
        start=1
    ):

        knowledge_type = item.get(
            "type",
            "unknown"
        )

        name = item.get(
            "name",
            "unknown"
        )

        source = item.get(
            "source",
            "unknown"
        )

        if knowledge_type == "term":
            detail = item.get(
                "definition",
                ""
            )

        elif knowledge_type == "business_rule":
            detail = item.get(
                "rule",
                ""
            )

        elif knowledge_type == "metric":
            detail = item.get(
                "definition",
                ""
            )

        elif knowledge_type == "entity":
            detail = item.get(
                "description",
                ""
            )

        elif knowledge_type == "sql_example":
            detail = item.get(
                "sql",
                ""
            )

        else:
            detail = ""

        context.append(
            f"FACK {index}\n"
            f"TYPE: {knowledge_type}\n"
            f"NAME: {name}\n"
            f"SOURCE: {source}\n"
            f"CONTENT: {detail}"
        )

    return "\n\n".join(
        context
    )


# ============================================================
# CENTRAL DATA CATALOG
# ============================================================

def load_catalog():
    """Load Central Data Catalog tu JSON."""

    if not CATALOG_FILE.exists():
        return []

    try:
        with open(
            CATALOG_FILE,
            "r",
            encoding="utf-8"
        ) as file:
            return json.load(file)

    except (
        json.JSONDecodeError,
        OSError
    ):
        return []


def select_catalog_sources(
    catalog,
    domain
):
    """Chon source active thuoc domain."""

    sources = []

    for item in catalog:

        item_domain = item.get(
            "domain",
            []
        )

        status = item.get(
            "status"
        )

        source = item.get(
            "source"
        )

        if domain not in item_domain:
            continue

        if status != "active":
            continue

        if not source:
            continue

        sources.append(
            source
        )

    return sources


def normalize_source(source):
    """Chuan hoa source de so sanh."""

    return str(
        source
    ).replace(
        "\\",
        "/"
    ).lower()


def filter_by_catalog(
    documents,
    allowed_sources
):
    """Chi giu document thuoc source duoc Catalog cho phep."""

    if not documents:
        return []

    allowed_sources = {
        normalize_source(source)
        for source in allowed_sources
    }

    return [
        document
        for document in documents
        if normalize_source(
            document.get(
                "source",
                ""
            )
        ) in allowed_sources
    ]


# ============================================================
# QUERY CONTEXTUALIZATION
# ============================================================

def contextualize_query(query, memory):
    """Rewrite query phu thuoc context thanh query day du."""

    if not memory:
        return query

    prompt = f"""
Bạn là module Query Contextualization của hệ thống RAG.

Nhiệm vụ:
Viết lại CURRENT QUESTION thành một câu hỏi đầy đủ
dựa trên CONVERSATION MEMORY.

Mục tiêu:
- Giải quyết các đại từ như: nó, này, đó, họ, cái này.
- Giải quyết các câu hỏi phụ thuộc vào câu trước.
- Giữ nguyên ý nghĩa câu hỏi hiện tại.
- Nếu câu hỏi đã đầy đủ, giữ nguyên hoặc chỉ chỉnh rất ít.
- Không trả lời câu hỏi.
- Không thêm thông tin mới.
- Chỉ trả về câu hỏi đã viết lại.
- Không giải thích.

CONVERSATION MEMORY:
{memory}

CURRENT QUESTION:
{query}

REWRITTEN QUESTION:
"""

    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": OLLAMA_MODEL,
                "prompt": prompt,
                "stream": False
            },
            timeout=300
        )

        response.raise_for_status()

        rewritten = response.json().get(
            "response",
            ""
        ).strip()

        if not rewritten:
            return query

        rewritten = rewritten.replace(
            "REWRITTEN QUESTION:",
            ""
        ).strip()

        return rewritten or query

    except requests.exceptions.RequestException:
        return query


# ============================================================
# LLM
# ============================================================

def ask_llm(
    query,
    fack_context,
    document_context,
    memory
):
    """Gui query, memory va RAG context cho Ollama."""

    prompt = f"""
Bạn là trợ lý Second Brain.

Bạn có ba nguồn context:

1. CONVERSATION MEMORY:
Lịch sử hội thoại trước đó.
Dùng memory để hiểu ngữ cảnh của câu hỏi hiện tại.

2. FACK CONTEXT:
Knowledge có cấu trúc về term, entity, business rule, metric
và SQL example được trích xuất từ knowledge base.

3. DOCUMENT CONTEXT:
Nội dung document được RAG retrieval và reranker chọn ra.

RULES:

- Dùng Conversation Memory để hiểu ngữ cảnh.
- Dùng Fack Context để bổ sung knowledge có cấu trúc.
- Dùng Document Context làm nguồn tài liệu chính để trả lời.
- Không dùng memory như nguồn kiến thức chính.
- Không tự thêm kiến thức bên ngoài các context trên.
- Không bịa thông tin.
- Nếu Fack và Document Context không đủ thông tin, hãy nói:
"Tài liệu không cung cấp đủ thông tin để trả lời câu hỏi này."

CONVERSATION MEMORY:
{memory}

FACK CONTEXT:
{fack_context}

DOCUMENT CONTEXT:
{document_context}

CURRENT QUESTION:
{query}

ANSWER:
"""

    try:

        response = requests.post(
            OLLAMA_URL,
            json={
                "model": OLLAMA_MODEL,
                "prompt": prompt,
                "stream": False
            },
            timeout=300
        )

        response.raise_for_status()

        return response.json().get(
            "response",
            ""
        ).strip()

    except requests.exceptions.RequestException:
        return ""


# ============================================================
# DISPLAY RESULTS
# ============================================================

def display_results(
    title,
    results,
    limit=5
):
    """Hien thi source va mot phan noi dung document."""

    print()

    print(
        f"{TITLE}  {title}:{Style.RESET_ALL}"
        f" {len(results)} results"
    )

    for index, result in enumerate(
        results[:limit],
        start=1
    ):

        document = result.get(
            "document",
            {}
        )

        source = document.get(
            "source",
            "unknown"
        )

        content = document.get(
            "content",
            ""
        )

        content = content.replace(
            "\n",
            " "
        ).strip()

        if len(content) > 150:

            content = (
                content[:150]
                + "..."
            )

        print(
            f"    [{index}] {source}"
        )

        print(
            f"        {content}"
        )


# ============================================================
# DISPLAY FACK
# ============================================================

def display_fack_results(
    results
):
    """Display Fack search results with clean spacing."""

    print()

    print(
        f"{TITLE}  Fack Search:{Style.RESET_ALL}"
        f" {len(results)} results"
    )

    if not results:
        print("    None")
        return

    for index, item in enumerate(
        results,
        start=1
    ):

        knowledge_type = item.get(
            "type",
            "unknown"
        )

        name = item.get(
            "name",
            "unknown"
        )

        source = item.get(
            "source",
            "unknown"
        )

        if knowledge_type == "term":
            detail = item.get("definition", "")
        elif knowledge_type == "business_rule":
            detail = item.get("rule", "")
        elif knowledge_type == "metric":
            detail = item.get("definition", "")
        elif knowledge_type == "entity":
            detail = item.get("description", "")
        elif knowledge_type == "sql_example":
            detail = item.get("sql", "")
        else:
            detail = ""

        print(f"    FACK {index}:")
        print(f"      TYPE: {knowledge_type}")
        print(f"      NAME: {name}")
        print(f"      SOURCE: {source}")
        print(f"      CONTENT: {detail}")

        if index < len(results):
            print()


def display_final_llm_context(
    fack_context,
    document_context
):
    """Display the exact context assembled for the LLM."""

    print()

    print(
        f"{TITLE}  Final LLM Context:{Style.RESET_ALL}"
    )

    print(
        "    FACK CONTEXT:"
    )

    if fack_context:

        for line in fack_context.splitlines():

            if line.strip():
                print(
                    f"      {line}"
                )

    else:
        print(
            "      None"
        )

    print()

    print(
        "    DOCUMENT CONTEXT:"
    )

    if document_context:

        for line in document_context.splitlines():

            if line.strip():
                print(
                    f"      {line}"
                )

    else:
        print(
            "      None"
        )


# ============================================================
# DISPLAY CATALOG
# ============================================================

def display_catalog(
    sources
):
    """Hien thi cac source duoc Catalog chon."""

    print()

    print(
        f"{TITLE}  Central Data Catalog:"
        f"{Style.RESET_ALL}"
        f" {len(sources)} sources"
    )

    for source in sources:

        print(
            f"    {Path(source).name}"
        )


# ============================================================
# BUILD CONTEXT
# ============================================================

def build_context(
    results
):
    """Gom documents sau reranking thanh context."""

    context = []

    for index, result in enumerate(
        results,
        start=1
    ):

        document = result.get(
            "document",
            {}
        )

        context.append(
            f"CHUNK {index}\n"
            f"SOURCE: {document.get('source', 'unknown')}\n"
            f"CONTENT:\n{document.get('content', '')}"
        )

    return "\n\n".join(
        context
    )


# ============================================================
# DISPLAY EVALUATION
# ============================================================

def display_evaluation(
    result
):
    """Hien ket qua evaluation."""

    print()

    print(
        f"{TITLE}  Evaluation:{Style.RESET_ALL}"
    )

    print(
        "    - Faithfulness:",
        result["faithfulness"],
        "/10"
    )

    print(
        "    - Groundedness:",
        result["groundedness"],
        "/10"
    )

    print(
        "    - Relevance:",
        result["answer_relevance"],
        "/10"
    )

    print(
        "    - Correctness:",
        result["correctness"],
        "/10"
    )

    print(
        "    - Overall:",
        result["overall"],
        "/10"
    )


# ============================================================
# RAG PIPELINE
# ============================================================

def run_rag(
    query
):
    """Chay query qua toan bo RAG pipeline."""

    print()

    print(
        f"{TITLE}Processing:{Style.RESET_ALL}"
    )

    # ========================================================
    # 1. LOAD MEMORY + QUERY CONTEXTUALIZATION
    # ========================================================

    memory = get_recent_memory()

    print()

    print(
        f"{TITLE}  Memory Context:{Style.RESET_ALL}",
        "loaded"
        if memory
        else "empty"
    )

    contextualized_query = contextualize_query(
        query,
        memory
    )

    if contextualized_query != query:

        print(
            f"{TITLE}  Contextualized Query:{Style.RESET_ALL}",
            contextualized_query
        )

    # ========================================================
    # 2. QUERY UNDERSTANDING
    # ========================================================

    query_info = understand_query(
        contextualized_query
    )

    if not query_info:

        print()

        print(
            f"{TITLE}  Query Understanding:"
            f"{Style.RESET_ALL}"
            " failed"
        )

        return None

    print()

    print(
        f"{TITLE}  Query Understanding:"
        f"{Style.RESET_ALL}"
    )

    print(
        "    - intent:",
        query_info.get("intent")
    )

    print(
        "    - domain:",
        query_info.get("domain")
    )

    print(
        "    - topic:",
        query_info.get("topic")
    )

    # ========================================================
    # 2. NER
    # ========================================================

    ner_result = extract_entities(
        contextualized_query
    )

    ner_entities = ner_result.get(
        "entities",
        []
    )

    print()

    print(
        f"{TITLE}  NER:{Style.RESET_ALL}"
    )

    if ner_entities:

        for entity in ner_entities:

            print(
                "    -",
                entity.get("text"),
                "→",
                entity.get("type")
            )

    else:

        print(
            "    - None"
        )

    # ========================================================
    # 3. ENTITY RESOLUTION
    # ========================================================

    resolution_result = resolve_entities(
        ner_entities
    )

    resolved_entities = resolution_result.get(
        "resolved",
        []
    )

    not_found = resolution_result.get(
        "not_found",
        []
    )

    ambiguous = resolution_result.get(
        "ambiguous",
        []
    )

    print()

    print(
        f"{TITLE}  Entity Resolution:"
        f"{Style.RESET_ALL}"
    )

    if resolved_entities:

        for entity in resolved_entities:

            print(
                "    -",
                entity.get("canonical_name"),
                "→",
                entity.get("entity_id")
            )

    elif ambiguous:

        print(
            "    - AMBIGUOUS"
        )

    elif not_found:

        print(
            "    - NOT_FOUND"
        )

    else:

        print(
            "    - None"
        )

    # ========================================================
    # ENTITY VALIDATION
    # ========================================================

    if ambiguous:

        print()

        print(
            f"{TITLE}  RAG:{Style.RESET_ALL}"
            " entity is ambiguous"
        )

        return None

    if ner_entities and not resolved_entities:

        print()

        print(
            f"{TITLE}  RAG:{Style.RESET_ALL}"
            " entity not found"
        )

        return None

    # ========================================================
    # 4. CENTRAL DATA CATALOG
    # ========================================================

    domain = query_info.get(
        "domain"
    )

    catalog = load_catalog()

    allowed_sources = select_catalog_sources(
        catalog,
        domain
    )

    display_catalog(
        allowed_sources
    )

    if not allowed_sources:

        print()

        print(
            f"{TITLE}  Central Data Catalog:"
            f"{Style.RESET_ALL}"
            " no valid source"
        )

        return None

    # ========================================================
    # 5. FACK SEARCH
    # ========================================================

    fack_results = search_fack(
        contextualized_query,
        domain,
        resolved_entities,
        top_k=FACK_TOP_K,
        allowed_sources=allowed_sources
    )

    display_fack_results(
        fack_results
    )

    fack_context = build_fack_context(
        fack_results
    )

    display_catalog(
        allowed_sources
    )

    if not allowed_sources:

        print()

        print(
            f"{TITLE}  Central Data Catalog:"
            f"{Style.RESET_ALL}"
            " no valid source"
        )

        return None

    # ========================================================
    # 5. DOMAIN SEARCH
    # ========================================================

    domain_results = domain_search(
        contextualized_query,
        domain,
        top_k=DOMAIN_TOP_K
    )

    domain_results = [
        result
        for result in domain_results
        if normalize_source(
            result.get(
                "document",
                {}
            ).get(
                "source",
                ""
            )
        )
        in {
            normalize_source(source)
            for source in allowed_sources
        }
    ]

    display_results(
        "Domain Search",
        domain_results,
        DOMAIN_TOP_K
    )

    search_documents = [
        result["document"]
        for result in domain_results
        if "document" in result
    ]

    # ========================================================
    # 6. VECTOR SEARCH
    # ========================================================

    search_results = search(
        contextualized_query,
        documents=search_documents,
        top_k=SEARCH_TOP_K
    )

    display_results(
        "Search",
        search_results,
        SEARCH_TOP_K
    )

    # ========================================================
    # 7. RAG RETRIEVAL
    # ========================================================

    retrieval_results = retrieve(
        query=contextualized_query,
        domain=domain,
        resolved_entities=resolved_entities,
        top_k=RETRIEVAL_TOP_K
    )

    retrieval_results = [
        result
        for result in retrieval_results
        if normalize_source(
            result.get(
                "document",
                {}
            ).get(
                "source",
                ""
            )
        )
        in {
            normalize_source(source)
            for source in allowed_sources
        }
    ]

    display_results(
        "RAG Retrieval",
        retrieval_results,
        RETRIEVAL_TOP_K
    )

    candidate_documents = [
        result["document"]
        for result in retrieval_results
        if result.get("document")
    ]

    if not candidate_documents:

        print()

        print(
            f"{TITLE}  RAG Retrieval:"
            f"{Style.RESET_ALL}"
            " no documents"
        )

        return None

    # ========================================================
    # 8. HYBRID SEARCH
    # ========================================================

    hybrid_results = hybrid_search(
        contextualized_query,
        documents=candidate_documents,
        top_k=HYBRID_TOP_K
    )

    display_results(
        "Hybrid Search",
        hybrid_results,
        HYBRID_TOP_K
    )

    if not hybrid_results:

        print()

        print(
            f"{TITLE}  Hybrid Search:"
            f"{Style.RESET_ALL}"
            " no results"
        )

        return None

    # ========================================================
    # 9. RERANKER
    # ========================================================

    reranked_results = rerank(
        contextualized_query,
        hybrid_results,
        top_k=RERANK_TOP_K
    )

    display_results(
        "Reranker",
        reranked_results,
        RERANK_TOP_K
    )

    if not reranked_results:

        print()

        print(
            f"{TITLE}  LLM:{Style.RESET_ALL}"
            " no context"
        )

        return None

    # ========================================================
    # 13. BUILD DOCUMENT CONTEXT
    # ========================================================

    document_context = build_context(
        reranked_results
    )

    display_final_llm_context(
        fack_context,
        document_context
    )

    # Keep one combined context for evaluation compatibility.
    context = f"""
FACK CONTEXT:
{fack_context}

DOCUMENT CONTEXT:
{document_context}
""".strip()

    # ========================================================
    # 14. LLM
    # ========================================================

    answer = ask_llm(
        contextualized_query,
        fack_context,
        document_context,
        memory
    )

    print()

    print(
        f"{TITLE}  LLM:{Style.RESET_ALL}",
        "generated"
        if answer
        else "failed"
    )

    if not answer:
        return None

    # ========================================================
    # 13. MEMORY
    # ========================================================

    history = load_memory()

    add_message(
        history,
        "user",
        query
    )

    add_message(
        history,
        "assistant",
        answer
    )

    print()

    print(
        f"{TITLE}  Memory:{Style.RESET_ALL}",
        len(history),
        "messages"
    )

    # ========================================================
    # 14. EVALUATION
    # ========================================================

    evaluation_result = evaluate_rag(
        query,
        context,
        answer
    )

    display_evaluation(
        evaluation_result
    )

    # ========================================================
    # RETURN RESULT
    # ========================================================

    return {
        "query": query,
        "contextualized_query": contextualized_query,
        "query_understanding": query_info,
        "ner": ner_result,
        "entity_resolution": resolution_result,
        "catalog_sources": allowed_sources,
        "fack_results": fack_results,
        "fack_context": fack_context,
        "domain_results": domain_results,
        "search_results": search_results,
        "retrieval_results": retrieval_results,
        "hybrid_results": hybrid_results,
        "reranked_results": reranked_results,
        "context": context,
        "memory": memory,
        "answer": answer,
        "evaluation": evaluation_result
    }


# ============================================================
# USER INPUT
# ============================================================

def get_question():
    """Nhan query va cho phep nhan ESC de thoat."""

    print()

    print(
        "Enter your question (Press ESC to Quit): ",
        end="",
        flush=True
    )

    query = ""

    while True:

        key = msvcrt.getwch()

        if key == "\x1b":

            print()

            print(
                f"{TITLE}RAG system stopped:"
                f"{Style.RESET_ALL}"
            )

            return None

        if key in (
            "\r",
            "\n"
        ):

            print()

            return query.strip()

        if key == "\b":

            if query:

                query = query[:-1]

                print(
                    "\b \b",
                    end="",
                    flush=True
                )

            continue

        if key in (
            "\x00",
            "\xe0"
        ):

            msvcrt.getwch()

            continue

        query += key

        print(
            key,
            end="",
            flush=True
        )


# ============================================================
# MAIN
# ============================================================

def main():
    """Khoi dong RAG system va cho phep hoi nhieu cau."""

    print(
        f"{TITLE}Second Brain RAG:{Style.RESET_ALL}"
    )

    initialize_system()

    while True:

        query = get_question()

        if query is None:
            break

        if not query:
            continue

        result = run_rag(
            query
        )

        if not result:
            continue

        print()

        print(
            f"{TITLE}Answer:{Style.RESET_ALL}"
        )

        print(
            result["answer"]
        )


# ============================================================
# START
# ============================================================

if __name__ == "__main__":
    main()