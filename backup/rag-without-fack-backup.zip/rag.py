from pathlib import Path
import json
import requests
import msvcrt
import re
import subprocess
import sys

from tqdm import tqdm
from colorama import Fore, Style, init

from query_understanding import understand_query, load_domains
from ner import extract_entities
from entity_resolution import resolve_entities, build_candidates
from domain_search import domain_search
from search import search
from rag_retrieval import retrieve
from hybrid_search import hybrid_search
from reranker import rerank

from memory import (
    load_memory,
    add_user_message,
    add_assistant_message,
    get_recent_memory,
    get_memory_text,
    get_last_entity
)

from evaluation import evaluate_rag


# ============================================================
# COLOR
# ============================================================

init(autoreset=True)

TITLE = Fore.GREEN


# ============================================================
# CONFIG
# ============================================================

PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_DIR / "data"

CATALOG_FILE = DATA_DIR / "data_catalog.json"

OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2"

DOMAIN_TOP_K = 5
SEARCH_TOP_K = 5
RETRIEVAL_TOP_K = 5
HYBRID_TOP_K = 5
RERANK_TOP_K = 2


# ============================================================
# SYSTEM INITIALIZATION
# ============================================================

def initialize_system():
    """Load and initialize RAG system modules."""

    steps = [
        ("Query Understanding", load_domains),
        ("NER", lambda: True),
        ("Entity Resolution", build_candidates),
        ("Central Data Catalog", load_catalog),
        ("Domain Search", lambda: True),
        ("Search", lambda: True),
        ("RAG Retrieval", lambda: True),
        ("Hybrid Search", lambda: True),
        ("Reranker", lambda: True),
        ("Memory", load_memory),
        ("Evaluation", lambda: True)
    ]

    for _, function in tqdm(
        steps,
        desc="Loading system",
        unit="module",
        dynamic_ncols=True,
        bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt}"
    ):
        function()

    print("System ready.")


# ============================================================
# CENTRAL DATA CATALOG
# ============================================================

def load_catalog():
    """Load Central Data Catalog."""

    if not CATALOG_FILE.exists():
        return []

    try:

        with open(
            CATALOG_FILE,
            "r",
            encoding="utf-8"
        ) as file:

            return json.load(file)

    except (
        json.JSONDecodeError,
        OSError
    ):

        return []


def select_catalog_sources(
    catalog,
    domain
):
    """Select active sources for a domain."""

    sources = []

    for item in catalog:

        item_domain = item.get(
            "domain",
            []
        )

        status = item.get(
            "status"
        )

        source = item.get(
            "source"
        )

        if domain not in item_domain:
            continue

        if status != "active":
            continue

        if not source:
            continue

        sources.append(
            source
        )

    return sources


def normalize_source(source):
    """Normalize source path."""

    return str(
        source
    ).replace(
        "\\",
        "/"
    ).lower()


# ============================================================
# SETUP DATA
# ============================================================

def setup_data():
    """Run run_build_data.py to setup RAG data."""

    build_file = (
        Path(__file__).resolve().parent.parent
        / "scripts"
        / "run_build_data.py"
    )

    print()

    print(
        f"{TITLE}Setup data:{Style.RESET_ALL}"
    )

    if not build_file.exists():

        print(
            "run_build_data.py not found."
        )

        print(
            "Expected path:",
            build_file
        )

        return False

    print(
        "Setting up data..."
    )

    result = subprocess.run(
        [
            sys.executable,
            str(build_file)
        ],
        cwd=build_file.parent
    )

    print()

    if result.returncode == 0:

        print(
            f"{TITLE}Setup data finished!"
            f"{Style.RESET_ALL}"
        )

        return True

    print(
        f"{TITLE}Setup data failed!"
        f"{Style.RESET_ALL}"
    )

    return False


# ============================================================
# QUERY CONTEXTUALIZATION
# ============================================================

def contextualize_query(
    query,
    memory
):
    """
    Resolve references using the latest entity
    from conversation memory.

    Example:

        C# la gi?

        Ung dung cua no la gi?

    Becomes:

        Ung dung cua C# la gi?
    """

    if not memory:
        return query

    entity = get_last_entity()

    if not entity:
        return query

    canonical_name = entity.get(
        "canonical_name"
    )

    if not canonical_name:
        return query

    reference_words = [
        "cái này",
        "cai nay",
        "cái đó",
        "cai do",
        "công cụ này",
        "cong cu nay",
        "ngôn ngữ này",
        "ngon ngu nay",
        "phần mềm này",
        "phan mem nay",
        "nó",
        "no",
        "này",
        "nay",
        "đó",
        "do"
    ]

    rewritten_query = query

    for reference in reference_words:

        pattern = re.escape(
            reference
        )

        if re.search(
            pattern,
            rewritten_query,
            flags=re.IGNORECASE
        ):

            rewritten_query = re.sub(
                pattern,
                canonical_name,
                rewritten_query,
                count=1,
                flags=re.IGNORECASE
            )

            break

    return rewritten_query


# ============================================================
# LLM
# ============================================================

def ask_llm(
    query,
    context,
    memory
):
    """Send query, memory and RAG context to Ollama."""

    prompt = f"""
Bạn là trợ lý Second Brain.

Bạn có hai nguồn context:

1. CONVERSATION MEMORY

Lịch sử hội thoại trước đó.

2. RAG CONTEXT

Thông tin được truy xuất từ knowledge base.

RULES:

- Conversation Memory chỉ dùng để hiểu ngữ cảnh.
- RAG Context là nguồn thông tin chính để trả lời.
- Không dùng kiến thức bên ngoài RAG Context.
- Không bịa thông tin.
- Nếu RAG Context không đủ thông tin, hãy nói:

"Tài liệu không cung cấp đủ thông tin để trả lời câu hỏi này."

CONVERSATION MEMORY:

{memory}

RAG CONTEXT:

{context}

CURRENT QUESTION:

{query}

ANSWER:
"""

    try:

        response = requests.post(
            OLLAMA_URL,
            json={
                "model": OLLAMA_MODEL,
                "prompt": prompt,
                "stream": False
            },
            timeout=300
        )

        response.raise_for_status()

        return response.json().get(
            "response",
            ""
        ).strip()

    except requests.exceptions.RequestException:

        return ""


# ============================================================
# DISPLAY RESULTS
# ============================================================

def display_results(
    title,
    results,
    limit=5
):
    """Display search results with clean section spacing."""

    print()

    print(
        f"{TITLE}  {title}:{Style.RESET_ALL}"
    )

    for index, result in enumerate(
        results[:limit],
        start=1
    ):

        document = result.get(
            "document",
            {}
        )

        source = document.get(
            "source",
            "unknown"
        )

        content = document.get(
            "content",
            ""
        )

        content = content.replace(
            "\n",
            " "
        ).strip()

        if len(content) > 150:

            content = (
                content[:150]
                + "..."
            )

        print(
            f"    - [{index}] {source}: {content}"
        )


# ============================================================
# DISPLAY CATALOG
# ============================================================

def display_catalog(
    sources
):
    """Display selected catalog sources."""

    print()

    print(
        f"{TITLE}  Central Data Catalog:"
        f"{Style.RESET_ALL}"
    )

    for source in sources:

        print(
            f"    - {Path(source).name}"
        )


# ============================================================
# BUILD CONTEXT
# ============================================================

def build_context(
    results
):
    """Build context for LLM."""

    context = []

    for index, result in enumerate(
        results,
        start=1
    ):

        document = result.get(
            "document",
            {}
        )

        context.append(
            f"CHUNK {index}\n"
            f"SOURCE: {document.get('source', 'unknown')}\n"
            f"CONTENT:\n{document.get('content', '')}"
        )

    return "\n\n".join(
        context
    )


# ============================================================
# DISPLAY EVALUATION
# ============================================================

def display_evaluation(
    result
):
    """Display evaluation result."""

    print()

    print()
    print(
        f"{TITLE}  Evaluation:{Style.RESET_ALL}"
    )

    print(
        f"    - Faithfulness: {result['faithfulness']} /10"
    )

    print(
        f"    - Groundedness: {result['groundedness']} /10"
    )

    print(
        f"    - Relevance: {result['answer_relevance']} /10"
    )

    print(
        f"    - Correctness: {result['correctness']} /10"
    )

    print(
        f"    - Overall: {result['overall']} /10"
    )


# ============================================================
# RAG PIPELINE
# ============================================================

def run_rag(
    query
):
    """Run query through the complete RAG pipeline."""

    print()

    print(
        f"{TITLE}Processing:{Style.RESET_ALL}"
    )

    # ========================================================
    # 1. MEMORY
    # ========================================================

    memory = get_recent_memory()

    memory_text = get_memory_text()

    print(
        f"{TITLE}  Memory:{Style.RESET_ALL}",
        "loaded"
        if memory
        else "empty"
    )

    # ========================================================
    # 2. ENTITY MEMORY / REFERENCE RESOLUTION
    # ========================================================

    last_entity = get_last_entity()

    if last_entity:

        print(
            f"{TITLE}  Memory Entity:"
            f"{Style.RESET_ALL}",
            last_entity.get(
                "canonical_name",
                "unknown"
            )
        )

    else:

        print(
            f"{TITLE}  Memory Entity:"
            f"{Style.RESET_ALL}",
            "None"
        )

    contextualized_query = contextualize_query(
        query,
        memory
    )

    print(
        f"{TITLE}  Contextualized Query:"
        f"{Style.RESET_ALL}",
        contextualized_query
    )

    # ========================================================
    # 3. QUERY UNDERSTANDING
    # ========================================================

    query_info = understand_query(
        contextualized_query
    )

    if not query_info:

        print(
            f"{TITLE}  Query Understanding:"
            f"{Style.RESET_ALL}",
            "failed"
        )

        return None

    print()
    print(
        f"{TITLE}  Query Understanding:"
        f"{Style.RESET_ALL}"
    )

    print(
        f"    - intent: {query_info.get('intent')}"
    )

    print(
        f"    - domain: {query_info.get('domain')}"
    )

    print(
        f"    - topic: {query_info.get('topic')}"
    )

    # ========================================================
    # 4. NER
    # ========================================================

    ner_result = extract_entities(
        contextualized_query
    )

    ner_entities = ner_result.get(
        "entities",
        []
    )

    print()
    print(
        f"{TITLE}  NER:{Style.RESET_ALL}"
    )

    for entity in ner_entities:

        print(
            f"    - {entity.get('text')} → {entity.get('type')}"
        )

    # ========================================================
    # 5. ENTITY RESOLUTION
    # ========================================================

    resolution_result = resolve_entities(
        ner_entities
    )

    resolved_entities = resolution_result.get(
        "resolved",
        []
    )

    not_found = resolution_result.get(
        "not_found",
        []
    )

    ambiguous = resolution_result.get(
        "ambiguous",
        []
    )

    print()
    print(
        f"{TITLE}  Entity Resolution:"
        f"{Style.RESET_ALL}"
    )

    for entity in resolved_entities:

        print(
            f"    - {entity.get('canonical_name')} "
            f"→ {entity.get('entity_id')}"
        )

    if ambiguous:

        print(
            "    - AMBIGUOUS"
        )

    if not_found:

        print(
            f"    - NOT_FOUND: {len(not_found)}"
        )

    # ========================================================
    # ENTITY VALIDATION
    # ========================================================

    if ambiguous:

        print(
            f"{TITLE}  RAG:{Style.RESET_ALL}",
            "entity is ambiguous"
        )

        return None

    if ner_entities and not resolved_entities:

        print(
            f"{TITLE}  RAG:{Style.RESET_ALL}",
            "entity not found"
        )

        return None

    # ========================================================
    # 6. CENTRAL DATA CATALOG
    # ========================================================

    domain = query_info.get(
        "domain"
    )

    catalog = load_catalog()

    allowed_sources = select_catalog_sources(
        catalog,
        domain
    )

    display_catalog(
        allowed_sources
    )

    if not allowed_sources:

        print(
            f"{TITLE}  Central Data Catalog:"
            f"{Style.RESET_ALL}",
            "no valid source"
        )

        return None

    allowed_source_set = {
        normalize_source(source)
        for source in allowed_sources
    }

    # ========================================================
    # 7. DOMAIN SEARCH
    # ========================================================

    domain_results = domain_search(
        contextualized_query,
        domain,
        top_k=DOMAIN_TOP_K
    )

    domain_results = [
        result
        for result in domain_results
        if normalize_source(
            result.get(
                "document",
                {}
            ).get(
                "source",
                ""
            )
        ) in allowed_source_set
    ]

    display_results(
        "Domain Search",
        domain_results,
        DOMAIN_TOP_K
    )

    search_documents = [
        result["document"]
        for result in domain_results
        if "document" in result
    ]

    # ========================================================
    # 8. SEARCH
    # ========================================================

    search_results = search(
        contextualized_query,
        documents=search_documents,
        top_k=SEARCH_TOP_K
    )

    display_results(
        "Search",
        search_results,
        SEARCH_TOP_K
    )

    # ========================================================
    # 9. RAG RETRIEVAL
    # ========================================================

    retrieval_results = retrieve(
        query=contextualized_query,
        domain=domain,
        resolved_entities=resolved_entities,
        top_k=RETRIEVAL_TOP_K
    )

    retrieval_results = [
        result
        for result in retrieval_results
        if normalize_source(
            result.get(
                "document",
                {}
            ).get(
                "source",
                ""
            )
        ) in allowed_source_set
    ]

    display_results(
        "RAG Retrieval",
        retrieval_results,
        RETRIEVAL_TOP_K
    )

    candidate_documents = [
        result["document"]
        for result in retrieval_results
        if result.get("document")
    ]

    if not candidate_documents:

        print(
            f"{TITLE}  RAG Retrieval:"
            f"{Style.RESET_ALL}",
            "no documents"
        )

        return None

    # ========================================================
    # 10. HYBRID SEARCH
    # ========================================================

    hybrid_results = hybrid_search(
        contextualized_query,
        documents=candidate_documents,
        top_k=HYBRID_TOP_K
    )

    display_results(
        "Hybrid Search",
        hybrid_results,
        HYBRID_TOP_K
    )

    if not hybrid_results:

        print(
            f"{TITLE}  Hybrid Search:"
            f"{Style.RESET_ALL}",
            "no results"
        )

        return None

    # ========================================================
    # 11. RERANKER
    # ========================================================

    reranked_results = rerank(
        contextualized_query,
        hybrid_results,
        top_k=RERANK_TOP_K
    )

    display_results(
        "Reranker",
        reranked_results,
        RERANK_TOP_K
    )

    if not reranked_results:

        print(
            f"{TITLE}  LLM:{Style.RESET_ALL}",
            "no context"
        )

        return None

    # ========================================================
    # 12. BUILD CONTEXT
    # ========================================================

    context = build_context(
        reranked_results
    )

    # ========================================================
    # 13. LLM
    # ========================================================

    answer = ask_llm(
        contextualized_query,
        context,
        memory_text
    )

    print(
        f"{TITLE}  LLM:{Style.RESET_ALL}",
        "generated"
        if answer
        else "failed"
    )

    if not answer:
        return None

    # ========================================================
    # 14. SAVE MEMORY + ENTITIES
    # ========================================================

    history = load_memory()

    add_user_message(
        history,
        query,
        resolved_entities
    )

    add_assistant_message(
        history,
        answer,
        resolved_entities
    )

    print(
        f"{TITLE}  Memory:{Style.RESET_ALL}",
        len(history),
        "messages",
        "| entities:",
        len(resolved_entities)
    )

    # ========================================================
    # 15. EVALUATION
    # ========================================================

    evaluation_result = evaluate_rag(
        query,
        context,
        answer
    )

    display_evaluation(
        evaluation_result
    )

    # ========================================================
    # RETURN RESULT
    # ========================================================

    return {
        "query": query,
        "contextualized_query": contextualized_query,
        "query_understanding": query_info,
        "ner": ner_result,
        "entity_resolution": resolution_result,
        "catalog_sources": allowed_sources,
        "domain_results": domain_results,
        "search_results": search_results,
        "retrieval_results": retrieval_results,
        "hybrid_results": hybrid_results,
        "reranked_results": reranked_results,
        "context": context,
        "memory": memory,
        "answer": answer,
        "evaluation": evaluation_result
    }


# ============================================================
# USER INPUT
# ============================================================

def get_question():
    """Get query and allow ESC to exit."""

    print()

    print(
        "Nhập câu hỏi của bạn (Nhấn ESC để Quit): ",
        end="",
        flush=True
    )

    query = ""

    while True:

        key = msvcrt.getwch()

        if key == "\x1b":

            print()

            print(
                f"{TITLE}RAG system stopped:"
                f"{Style.RESET_ALL}"
            )

            return None

        if key in (
            "\r",
            "\n"
        ):

            print()

            return query.strip()

        if key == "\b":

            if query:

                query = query[:-1]

                print(
                    "\b \b",
                    end="",
                    flush=True
                )

            continue

        if key in (
            "\x00",
            "\xe0"
        ):

            msvcrt.getwch()

            continue

        query += key

        print(
            key,
            end="",
            flush=True
        )


# ============================================================
# MAIN
# ============================================================

def main():
    """Start RAG system."""

    print(
        f"{TITLE}Second Brain RAG:{Style.RESET_ALL}"
    )

    initialize_system()

    while True:

        print()

        print(
            "Nếu chưa thiết lập dữ liệu, nhập: setup-data"
        )

        query = get_question()

        if query is None:
            break

        if not query:
            continue

        if query.lower() == "setup-data":

            setup_data()

            continue

        result = run_rag(
            query
        )

        if not result:
            continue

        print()

        print(
            f"{TITLE}Answer:{Style.RESET_ALL}"
        )

        print(
            result["answer"]
        )


# ============================================================
# START
# ============================================================

if __name__ == "__main__":
    main()